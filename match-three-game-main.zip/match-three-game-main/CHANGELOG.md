# Change Log

## v1.0.0 - 2021-03-01

Initial release.

**Added:**
- README
- CHANGELOG
- Core Functionality 
    - Users can match rows and columns of 3 + 
    - Users can see the score 
    - [Background was added: Ben Mack royalty free background](https://www.pexels.com/photo/magnificent-view-of-ocean-beneath-light-pink-sky-5326901/)
    - Fixed buf where 1st row sometimes would not generate
