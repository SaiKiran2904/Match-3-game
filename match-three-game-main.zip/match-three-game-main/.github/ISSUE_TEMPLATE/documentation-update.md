---
name: Documentation Update
about: Use this template for documentation requests or fixes
title: ''
labels: documentation, hacktoberfest
assignees: ''

---

**What doc(s) needs to be updated or corrected?**
- [ ] README
- [ ] CONTRIBUTING 
- [ ] CODE_OF_CONDUCT
- [ ] Other, please specify  
 
**Give a description of your update or correction**
Add any other context about the problem here.
